const { log } = require("./utils"); // Adjust the path as necessary
const settings = require("./config/config");

async function checkBaseUrl() {
  console.log("Checking API...");

  if (settings.ADVANCED_ANTI_DETECTION) {
    const result = getBaseApi();
    if (result.endpoint) {
      log("API has not changed.", "success");
      return result;
    }
  } else {
    return {
      endpoint: settings.BASE_URL,
      message:
        "If the API changes, please contact the Airdrop Script FA Telegram group for updates: https://t.me/airdropscriptfa",
    };
  }
}

function getBaseApi() {
  if (settings.BASE_URL) {
    return {
      endpoint: settings.BASE_URL,
      message: "Using configured BASE_URL.",
    };
  } else {
    return {
      endpoint: null,
      message:
        "BASE_URL is not set. Please contact the Forest Army group for assistance: https://t.me/forestarmy",
    };
  }
}

module.exports = { checkBaseUrl };